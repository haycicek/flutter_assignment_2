import 'package:flutter/material.dart';

void main() => runApp(QuizApp());

class QuizApp extends StatefulWidget {
  @override
  _QuizAppState createState() => _QuizAppState();
}

class _QuizAppState extends State<QuizApp> {
  final List<Map<String, Object>> _questions = [
    {
      'question': 'What is the capital city of Turkey?',
      'answers': [
        {'text': 'London', 'score': 0},
        {'text': 'Ankara', 'score': 1},
        {'text': 'Berlin', 'score': 0},
        {'text': 'Rome', 'score': 0},
      ],
    },
    {
      'question': 'What is the largest continent by land area?',
      'answers': [
        {'text': 'Africa', 'score': 0},
        {'text': 'Asia', 'score': 1},
        {'text': 'Europe', 'score': 0},
        {'text': 'South America', 'score': 0},
      ],
    },
    {
      'question': 'What is the tallest mammal?',
      'answers': [
        {'text': 'Elephant', 'score': 0},
        {'text': 'Giraffe', 'score': 1},
        {'text': 'Rhino', 'score': 0},
        {'text': 'Hippo', 'score': 0},
      ],
    },
    {
      'question': 'What is the currency of Turkey?',
      'answers': [
        {'text': 'Yuan', 'score': 0},
        {'text': 'Lira', 'score': 1},
        {'text': 'Euro', 'score': 0},
        {'text': 'Dollar', 'score': 0},
      ],
    },
  ];

  int _questionIndex = 0;
  int _score = 0;

  void _answerQuestion(int score) {
    _score += score;

    setState(() {
      _questionIndex++;
    });
  }

  void _resetQuiz() {
    setState(() {
      _questionIndex = 0;
      _score = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          title: Text('Quiz App'),
          backgroundColor: Colors.orange,
        ),
        body: _questionIndex < _questions.length
            ? QuizPage(
                questionIndex: _questionIndex,
                questions: _questions,
                answerQuestion: _answerQuestion,
              )
            : ResultPage(
                score: _score,
                resetQuiz: _resetQuiz,
              ),
      ),
    );
  }
}

class QuizPage extends StatelessWidget {
  final int questionIndex;
  final List<Map<String, Object>> questions;
  final Function answerQuestion;

  QuizPage({
    required this.questionIndex,
    required this.questions,
    required this.answerQuestion,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          questions[questionIndex]['question'] as String,
          style: TextStyle(
            color: Colors.white,
            fontSize: 20
            ),
        ),
        SizedBox(height: 20),
        ...(questions[questionIndex]['answers'] as List<Map<String, Object>>)
            .map((answer) => ElevatedButton(
                  onPressed: () => answerQuestion(answer['score'] as int),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.orange,
                  ),
                  child: Text(answer['text'] as String),
                ))
            .toList(),
      ],
    );
  }
}

class ResultPage extends StatelessWidget {
  final int score;
  final Function resetQuiz;

  ResultPage({
    required this.score,
    required this.resetQuiz,
  });

  String get resultPhrase {
    String resultText;
    if (score == 4) {
      resultText = 'UNBELIEVABLE!\nYou scored $score point';
    } 
    else if (score == 3) {
      resultText = 'PERFECT!\nYou scored $score point';
    } 
    else if (score == 2) {
      resultText = 'NICE!\nYou scored $score point';
    } 
    else if (score == 1) {
      resultText = 'GOOD!\nYou scored $score point';
    } 
    else {
      resultText = 'UNFORTUNATELY!\nYou scored $score points';
    }
    return resultText;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            resultPhrase,
            style: TextStyle(
              color: Colors.white,
              fontSize: 20),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => resetQuiz(),
            style: ElevatedButton.styleFrom(
                    primary: Colors.orange,
                  ),
            child: Text('Go Back'),
          ),
        ],
      ),
    );
  }
}
